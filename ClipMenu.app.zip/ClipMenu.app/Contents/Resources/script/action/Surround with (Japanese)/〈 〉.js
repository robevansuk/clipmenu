return '〈' + clipText + '〉';

