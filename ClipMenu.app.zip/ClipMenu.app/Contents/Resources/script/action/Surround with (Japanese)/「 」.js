return '「' + clipText + '」';

