return '【' + clipText + '】';

