return '（' + clipText + '）';

