return '《' + clipText + '》';

