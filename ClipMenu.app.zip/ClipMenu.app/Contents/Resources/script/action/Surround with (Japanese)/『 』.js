return '『' + clipText + '』';

