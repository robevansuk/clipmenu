return '"' + clipText + '"';

