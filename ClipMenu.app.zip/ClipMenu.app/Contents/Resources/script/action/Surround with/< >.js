return '<' + clipText + '>';

