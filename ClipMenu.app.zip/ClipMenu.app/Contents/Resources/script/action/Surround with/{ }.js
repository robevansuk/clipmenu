return '{' + clipText + '}';

